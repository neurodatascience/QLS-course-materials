#!/bin/bash

# The following command will print a message
echo "Thank you, very kind!"
