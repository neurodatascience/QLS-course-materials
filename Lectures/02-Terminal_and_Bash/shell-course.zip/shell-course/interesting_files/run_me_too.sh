#!/bin/bash

# The following command will print a message
echo "I didn't have execution permission and now I do. How nice."
